'use strict'

window.addEventListener('DOMContentLoaded', (event) => {

    const cartCounterEl = document.querySelector('.cart-main span');
    const cartTotalValueEl = document.querySelector('.cart-total-value');
    const cartOpen = document.querySelector('.cart-block');
    const renderItems = document.querySelector('.renderItems');
    const deleteItems = document.querySelector('.cart-delete');


    document.querySelector('.cart-main').addEventListener('click', () => {
        cartOpen.classList.toggle('invisible');
    });

    const cart = {};

    document.querySelector('.catalog').addEventListener('click', event => {
        if (!event.target.classList.contains('catalog-button')) {
            return;
        } 
        const catalogCard = event.target.closest('.catalog-card');
        const id = +catalogCard.dataset.id,
            name = catalogCard.dataset.name,
           price = +catalogCard.dataset.price;
        addToCart(id, name, price);

    });

    function addToCart(id, name, price) {
        if (!(id in cart)) {
            cart[id] = {
                id: id,
                name: name,
                price: price,
                count: 0 ,
            };
        }    
        cart[id].count++;
        cartCounterEl.textContent = getTotalCount();// считаем сколько всего товаров куплено
        cartTotalValueEl.textContent = getTotalCartPrice().toFixed(2);
        renderNewItemInCart(id);
    }

    function getTotalCount() { // считаем сколько всего товаров куплено
        
       return Object.values(cart).reduce((acc,product)=> acc+ product.count,0 );
    }

    function getTotalCartPrice() {
        return Object.values(cart).reduce((acc, product) => acc + product.count * product.price, 0);
    }

   // function renderItemInCart(id) {
    //    let renderedItems = document.querySelector('.renderedItems');
    //    document.querySelector('.catalog-button').addEventListener('click', () => {
    //        renderedItems.innerHTML = renderNewItemInCart();
       // }); 
   // }
    

    function renderNewItemInCart(productId) {
        const cartEl = renderItems.querySelector(`.renderedItems[data-productId="${productId}"]`);
        if (!cartEl) {
            const renderedCart = `
                        <div class="renderedItems" data-productId="${productId}">
                            <p class="in-cart-title">${cart[productId].name}</p>
                            <p class="in-catalog-price">${cart[productId].price}</p>
                            <p class="catalog-count">${cart[productId].count}</p>
                            <div class="cart-delete">X</div>
                        </div>
                        `; 
            renderItems.innerHTML += renderedCart;
        }
        cartEl.querySelector('.catalog-count').textContent = cart[productId].count;
        
    }

    function deleteFromCart(productId) {
        deleteItems.addEventListener('click', (event) => {
            let find = productId.find(product => product.id === productId)
            if (find.count > 1) {
                find.count--;
            }
    
        });
    }        
    deleteFromCart(productId);
});
