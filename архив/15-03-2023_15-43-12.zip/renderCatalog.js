'use strict'

window.addEventListener('DOMContentLoaded', (event) => {

let goods= [
    {
        "id_product": 1,
        "group": "brooch",
        "img": "img/catalog/1.jpg",
        "product_name": "Брошка с незабудками",
        "price": 800
    },
    {
        "id_product": 2,
        "group": "earnings",
        "img": "img/catalog/2.jpg",
        "product_name": "Серьги с белым озотамнусом",
        "price": 1000
    },
    {
        "id_product": 3,
        "group": "brooch",
        "img": "img/catalog/3.jpg",
        "product_name": "Брошка-кошка",
        "price": 800
    },
    {
        "id_product": 4,
        "group": "set",
        "img": "img/catalog/4.png",
        "product_name": "Набор с цветками лобелии",
        "price": 1300
    },
    {
        "id_product": 5,
        "group": "necklace",
        "img": "img/catalog/5.jpg",
        "product_name": "Кулон с розовым озотамнусом",
        "price": 900
    },
    {
        "id_product": 6,
        "group": "earnings",
        "img": "img/catalog/6.png",
        "product_name": "Серьги c васильками",
        "price": 800
    },
	{
        "id_product": 7,
        "group": "earnings",
        "img": "img/catalog/7.jpg",
        "product_name": "Серьги",
        "price": 950
    },
	{
        "id_product": 8,
        "group": "earnings",
        "img": "img/catalog/8.jpg",
        "product_name": "Серьги",
        "price": 800
    },
	{
        "id_product": 9,
        "group": "earnings",
        "img": "img/catalog/9.jpg",
        "product_name": "Серьги",
        "price": 1200
    },
]

const renderItem = (id_product, group, img, product_name, price) => {
    return `
                    <div class="catalog-card ${group}" data-id=${id_product} data-name=${product_name} data-price=${price}>
                        <img class="catalog-img" src=${img} alt="Каталог">
                        <div class="catalog-text">
                        <p class="catalog-title"=>${product_name}</p>
                        <p class="catalog-desc">oremLoremLoremLoremLoremLoremLoremLoremLoremLoremLoremLoremLorem</p>
                        <p class="catalog-materials">Материалы: <br>
                        Эпоксидная смола, сухоцветы	</p>
                        <p class="catalog-price">${price} рублей</p> 
                        </div>
                        <button class="catalog-button">Купить</button>
                    </div>
                    `  
};
    

const renderPage = (list) => {
    let itemsList = list.map(item => renderItem(item.id_product, item.group, item.img, item.product_name, item.price));
    document.querySelector('.catalog').innerHTML = itemsList.join('');
}
renderPage(goods);


});



//Функция вертски каждого товара
//const renderProduct = (product) => {
 // return `div class= "cart-item">
  //<img src="${img}">
 // <h3>${product.title}</h3>
 // <p>${product.price}</p>
//  <button class="catalog-button">Купить></button>

 // </div>`

//};
//const renderPage = list => {
 // document.querySelector(".catalog").innerHTML = (list.map(product => renderProduct(product))).join("");
//};

