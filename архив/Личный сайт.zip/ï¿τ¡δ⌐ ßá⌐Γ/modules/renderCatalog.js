'use strict'

window.addEventListener('DOMContentLoaded', (event) => {

let goods= [
    {
        "id_product": 1,
        "group": "brooch",
        "img": "img/catalog/1.jpg",
        "product_name": "Брошка с незабудками",
		"desc":"Небольшая брошка с настоящими незабудками. Воплощение женственности и весеннего настроения.",
		"materials": "Диаметр броши 3 см. Деревянная основа, сухоцветы, эпоксидная смола",
        "price": 800 
    },
    {
        "id_product": 2,
        "group": "earnings",
        "img": "img/catalog/2.jpg",
        "product_name": "Серьги с белым озотамнусом",
		"desc":"Маленькие воздушные сережки создают чувство невесомости",
		"materials":"Диаметр 1 см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 1200 
    },
    {
        "id_product": 3,
        "group": "brooch",
        "img": "img/catalog/3.jpg",
        "product_name": "Брошка-кошка с цветками спиреи японской",
		"desc":"Стильный акссесуар под женственный образ",
		"materials":"Высота броши 5 см. Деревянная основа, сухоцветы, эпоксидная смола",
        "price": 800
    },
    {
        "id_product": 4,
        "group": "set",
        "img": "img/catalog/4.jpg",
        "product_name": "Набор с цветками лобелии",
		"desc":"Сочный комплект цвета летнего неба",
		"materials":"Диаметр 2 см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 1300
    },
    {
        "id_product": 5,
        "group": "necklace",
        "img": "img/catalog/5.jpg",
        "product_name": "Кулон с розовым озотамнусом",
		"desc":"нежные цветы озотамнуса в основе этого кулона, способны создать образ естественной красоты и внести нотку весенней свежести.",
        "materials":"Высота кулона 5 см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
	    "price": 900
    },
    {
        "id_product": 6,
        "group": "earnings",
        "img": "img/catalog/6.jpg",
        "product_name": "Серьги c незабудками",
		"desc":"Стильные сережки дополнят любой образ",
		"materials":"Диаметр сережек 2,5 см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 800
    },
	{
        "id_product": 7,
        "group": "earnings",
        "img": "img/catalog/7.jpg",
        "product_name": "Серьги с вереском",
		"desc":"Маленькие сережки обратят на себя внимание интересным цветовым сочетанием",
		"materials":"Диаметр сережек 1 см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 950
    },
	{
        "id_product": 8,
        "group": "brooch",
        "img": "img/catalog/8.jpg",
        "product_name": "Брошь с букетом цветов",
		"desc":"Цветочная брошь с васильком, гортензией и озотамнусом",
		"materials":"Диаметр броши 3 см. Сухоцветы, эпоксидная смола",
        "price": 800
    },
	{
        "id_product": 9,
        "group": "set",
        "img": "img/catalog/9.jpg",
        "product_name": "Набор с вереском",
		"desc":"Изяшный комплект геометричной формы с вереском",
		"materials":"Размер квадратов 1,2*1,2 см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 1200
    },
	{
        "id_product": 10,
        "group": "brooch",
        "img": "img/catalog/10.jpg",
        "product_name": "Брошь с молочаем",
		"desc":"Оригинальная брошь обратит на себя внимание окружающих",
		"materials":"Диаметр броши 3см.Сухоцветы, эпоксидная смола",
        "price": 1200
    },
	{
        "id_product": 11,
        "group": "necklace",
        "img": "img/catalog/11.jpg",
        "product_name": "Кулон с гелихризумом",
		"desc":"Маленький кулон для тех, кто не любит крупные украшения",
		"materials":"Диаметр кулона 1 см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 1200
    },
	{
        "id_product": 12,
        "group": "necklace",
        "img": "img/catalog/12.jpg",
        "product_name": "Кулон с васильком",
		"desc":"Невесомый летний кулон с васильком",
		"materials":"Диаметр кулона 3см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 1200
    },
	{
        "id_product": 13,
        "group": "necklace",
        "img": "img/catalog/13.jpg",
        "product_name": "Кулон с цветами льна",
		"desc":"Композиция из цветов льна на белом фоне подчеркнет вашу индивидуальность",
		"materials":"Диаметр кулона 3см. Нержавеющая сталь, сухоцветы, эпоксидная смола.",
        "price": 1200
    },
	{
        "id_product": 14,
        "group": "set",
        "img": "img/catalog/14.jpg",
        "product_name": "Набор с цветками аниса",
		"desc":"Сочный набор подарит тебе хорошее настроение и обратит на себя внимание окружающих",
		"materials":"Диаметр кулона 3см, диаметр сережек 2см, диаметр кольца 1 см. Нержавеющая сталь, сухоцветы, эпоксидная смола",
        "price": 1200
    },
	{
        "id_product": 15,
        "group": "necklace",
        "img": "img/catalog/15.jpg",
        "product_name": "Кулон с цветками аниса",
		"desc":"Оригинальное цветовое сочетание подчеркнет вашу индивидуальность",
		"materials":"Диаметр кулона 3см. Нержавеющая сталь, сухоцветы, эпоксидная смола",
        "price": 800
    },
	{
        "id_product": 16,
        "group": "set",
        "img": "img/catalog/16.jpg",
        "product_name": "Набор с узором",
		"desc":"Необычный узор не оставит равнодушным никого вокруг",
		"materials":"Диаметр кулона 2см, диаметр кольца 2см. Нержавеющая сталь, акриловая краска, эпоксидная смола",
        "price": 800
    },
	{
        "id_product": 17,
        "group": "brooch",
        "img": "img/catalog/17.jpg",
        "product_name": "Брошка-кошка",
		"desc":"Брошка пастельных тонов с полевыми цветами подойдет под любой образ",
		"materials":"Деревянная основа, акриловая краска,сухоцветы, эпоксидная смола",
        "price": 800
    },
	{
        "id_product": 18,
        "group": "necklace",
        "img": "img/catalog/18.jpg",
        "product_name": "Кулон с полевыми цветами",
		"desc":"Букет полевых цветов в основе этого кулона создаст летнее настроение",
		"materials":"Бижутерный сплав,сухоцветы, эпоксидная смола",
        "price": 900
    },
	{
        "id_product": 19,
        "group": "necklace",
        "img": "img/catalog/19.jpg",
        "product_name": "Кулон с гелихризумом",
		"desc":"Большой кулон с гелихризумом, который хочется разглядывать и разглядывать",
		"materials":"Диаметр кулона 2 см. Нержвеющая сталь,сухоцветы, эпоксидная смола",
        "price": 900
    },
	{
        "id_product": 20,
        "group": "earnings",
        "img": "img/catalog/20.jpg",
        "product_name": "Серьши с одуванчиком",
		"desc":"Сережки с одуванчиком создают воздушное настроение расслабленности",
		"materials":"Диаметр сережек 1 см.Нержвеющая сталь,сухоцветы, эпоксидная смола",
        "price": 800
    },
	{
	    "id_product": 21,
        "group": "set",
        "img": "img/catalog/21.jpg",
        "product_name": "Набор с цветами молочая",
		"desc":"Стильный и сдержанный комлект для уверенных в себе",
		"materials":"Диаметр сережек 1,5 см. Нержвеющая сталь,сухоцветы, эпоксидная смола",
        "price": 1200
    },
	{
	    "id_product": 22,
        "group": "brooch",
        "img": "img/catalog/22.jpg",
        "product_name": "Брошь с полевыми цветами",
		"desc":"Цветочная поляна этой броши всегда напоминает о лете",
		"materials":"Диаметр броши 2 см. Нержвеющая сталь,сухоцветы, эпоксидная смола",
        "price": 800
    },
	{
	    "id_product": 23,
        "group": "set",
        "img": "img/catalog/23.jpg",
        "product_name": "Набор с незабудками",
		"desc":"Очаровательный набор с незабудками для весеннего настроения",
		"materials":"Нержвеющая сталь,деревянная основа,сухоцветы, эпоксидная смола",
        "price": 1300
    
	},
	{
	    "id_product": 24,
        "group": "earnings",
        "img": "img/catalog/24.jpg",
        "product_name": "Сережки с незабудками",
		"desc":"Очаровательне сережки с незабудками для весеннего настроения",
		"materials":"Нержвеющая сталь,деревянная основа,сухоцветы, эпоксидная смола",
        "price": 1300
    },
	{
	    "id_product": 25,
        "group": "set",
        "img": "img/catalog/25.jpg",
        "product_name": "Набор с незабудками",
		"desc":"Стильный набор с незабудками для женственного образа",
		"materials":"Нержвеющая сталь,деревянная основа,сухоцветы, эпоксидная смола",
        "price": 1100
    },
]


const renderItem = (id_product, group, img, product_name, desc,materials,price) => {
    return `
                    <div class="catalog-card ${group}" data-id=${id_product} data-name=${product_name} data-price=${price}>
                        <img class="catalog-img" src=${img} alt="Каталог">
                        <div class="catalog-text">
                        <p class="catalog-title"=>${product_name}</p>
                        <p class="catalog-desc"=>${desc}</p>
                        <p class="catalog-materials">${materials}</p>
                        <p class="catalog-price">Цена: ${price} рублей</p> 
                        </div>
						<div class="catalog-item-count">
						<div class="minus-count"><img src="img/minus-count.png" alt="minus"></div>
						<input type="text" name="count" value="1">
						<div class="plus-count"><img src="img/plus-count.png" alt="plus"></div>
						</div>
                        <button class="catalog-button">Купить</button>
                    </div>
                    `  
};
    

const renderPage = (list) => {
    let itemsList = list.map(item => renderItem(item.id_product, item.group, item.img, item.product_name,item.desc,item.materials, item.price));
    document.querySelector('.catalog').innerHTML = itemsList.join('');
}
renderPage(goods);


});



//Функция вертски каждого товара
//const renderProduct = (product) => {
 // return `div class= "cart-item">
  //<img src="${img}">
 // <h3>${product.title}</h3>
 // <p>${product.price}</p>
//  <button class="catalog-button">Купить></button>

 // </div>`

//};
//const renderPage = list => {
 // document.querySelector(".catalog").innerHTML = (list.map(product => renderProduct(product))).join("");
//};

