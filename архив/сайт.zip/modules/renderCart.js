'use strict'
window.addEventListener('DOMContentLoaded', (event) => {

    const cartQuantity = document.querySelector('.cart-main span');    
    const cartOpen = document.querySelector('.cart-block');
    const renderItems = document.querySelector('.renderItems');
    const toCartPage = document.querySelector('.toCartPage');
    let catalogButton = document.querySelectorAll('.catalog-button');
    let cartTotalValue = document.querySelector('.cart-total-value'); 
    let price = 0;
    
        

    const randomId = () => {
        return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    }; // генерирует рандом ID, чтобы приудалении из корзины товары связывались между каталожными
    //и корзинными

        const renderItemInCart = (id, img, title, price, count) => {
        
        return ` <div class="renderedItems" data-id="${id}">
		<div class="deleteItem"><img class="deleteItem-img" src="img/close.png"></div>
        <img src="${img}" alt="Товар" class="cart-product-img"> 
                                <p class="in-cart-title">${title}</p>
                                <p class="in-catalog-price">${price}</p>
                               
                                <div class="catalog-item-count">
						<btn class="minus-count"><img src="img/minus-count.png" alt="minus"></btn>
						<input ${count} type= "text" name="count"  value="1" maxlenght="3" class="stepper-input">
						<btn class="plus-count"><img src="img/plus-count.png" alt="plus"></btn>
						</div>
                            </div>`
            
        };
        
        const deleteProducts = (productParent) => {
            //получитьid
            //просчитать цену
            //пересчитать сумму 
            //и удалить сам товар
            
            //let id = productParent.querySelector('.renderedItems').dataset.id;
            //document.querySelector(`.product[data-id="${id}"]`)
            let currentPrice = productParent.querySelector('.in-catalog-price').textContent;


            minusFullPrice(currentPrice);
            printFullPrice();
            productParent.remove(); 
            printQuantity();
        }


        const plusFullPrice = (currentPrice) => {
            return price += parseInt(currentPrice);
        };
        const minusFullPrice = (currentPrice) => {
            return price -= parseInt(currentPrice);
        };
        const printFullPrice = () => {
            cartTotalValue.textContent = `${price}` ;
        };
        const printQuantity = () => {
            let length = renderItems.children.length;
            cartQuantity.textContent = length;
            length > 0 ? cartOpen.classList.remove('invisible') : cartOpen.classList.add('invisible')

        };
        

    catalogButton.forEach(el => {
        el.closest('.catalog-card').setAttribute('data-id', randomId());
        el.addEventListener('click', (e) => {
            let self = e.currentTarget;
            let parent = self.closest('.catalog-card');
            let id = parent.dataset.id;
            let img = parent.querySelector('.catalog-img').getAttribute('src');
            let title = parent.querySelector('.catalog-title').textContent;
            let priceNumber = parent.querySelector('.catalog-price').textContent;
            let count = parent.getElementsByTagName("input")[0];
            toCartPage.classList.remove('none');
            
            plusFullPrice(priceNumber);
            printFullPrice();
            renderItems.insertAdjacentHTML('afterbegin', renderItemInCart(id, img, title, priceNumber, count));
            printQuantity();

            document.querySelector('.cart-main').addEventListener('click', () => {
                cartOpen.classList.toggle('invisible');
            });
            document.querySelector('.cart-close img').addEventListener('click', () => {
                cartOpen.classList.toggle('invisible');
            });

        });
    });
        cartOpen.addEventListener('click', (e) => { // вызываем ф-цию удаления товара
        
            if (e.target.classList.contains('deleteItem-img')) {
                deleteProducts(e.target.closest('.renderedItems'))
            } 
        });
    
    
  //stepper
    const stepper = document.querySelectorAll('.catalog-item-count');
    const stepperInput = stepper.querySelectorAll('.stepper-input');
    console.log(stepperInput)
    const stepperPlus = stepper.querySelectorAll('.plus-count');
    const stepperMinus = stepper.querySelectorAll('.minus-count');

   let countInput = stepperInput.value;

    stepperInput.addEventListener('keyup', (e) => {
        let self = e.currentTarget;

        if (self.value == '0') {
            self.value = 1;
        }

        countInput = stepperInput.value;

        if (countInput == 1) {
            stepperMinus.classList.add('.stepper-btn-disabled');
        }
    });
 

});









































/*
.window.addEventListener('DOMContentLoaded', (event) => {

    const cartCounterEl = document.querySelector('.cart-main span');
    const cartTotalValueEl = document.querySelector('.cart-total-value');
    const cartOpen = document.querySelector('.cart-block');
    const renderItems = document.querySelector('.renderItems');
    const deleteItems = document.querySelectorAll('.deleteItem-img');
	const toCartPage = document.querySelector('.toCartPage');
	const catalogCount= document.querySelector('.catalogCount');                


    document.querySelector('.cart-main').addEventListener('click', () => {
        cartOpen.classList.toggle('invisible');
    });

    const cart = {};

    document.querySelector('.catalog').addEventListener('click', event => {
        if (!event.target.classList.contains('catalog-button')) {
            return;
        } 
        const catalogCard = event.target.closest('.catalog-card');
        const id = +catalogCard.dataset.id,
            name = catalogCard.dataset.name,
           price = +catalogCard.dataset.price;
        addToCart(id, name, price);

    });

    function addToCart(id, name, price) {
        if (!(id in cart)) {
            cart[id] = {
                id: id,
                name: name,
                price: price,
                count: 0 ,
            };
        }    
        cart[id].count++;
        cartCounterEl.textContent = getTotalCount();// считаем сколько всего товаров куплено
        cartTotalValueEl.textContent = getTotalCartPrice().toFixed(2);
        renderNewItemInCart(id);
    }

    function getTotalCount() { // считаем сколько всего товаров куплено
        
       return Object.values(cart).reduce((acc,product)=> acc+ product.count,0 );
    }

    function getTotalCartPrice() {
        return Object.values(cart).reduce((acc, product) => acc + product.count * product.price, 0);
    }

   // function renderItemInCart(id) {
    //    let renderedItems = document.querySelector('.renderedItems');
    //    document.querySelector('.catalog-button').addEventListener('click', () => {
    //        renderedItems.innerHTML = renderNewItemInCart();
       // }); 
   // }
    

    function renderNewItemInCart(productId) {
        const cartEl = renderItems.querySelector(`.renderedItems[data-productId="${productId}"]`);
        if (!cartEl) {
            const renderedCart = `
                        <div class="renderedItems" data-productId="${productId}">
                            <p class="in-cart-title">${cart[productId].name}</p>
                            <p class="in-catalog-price">${cart[productId].price}</p>
                            <p class="catalogCount">${cart[productId].count}</p>
                            <div class="cart-delete"><img src="img/close.png"></div>
                        </div>
                        `; 
            renderItems.innerHTML += renderedCart;
			toCartPage.classList.remove('none');
        }
        cartEl.querySelector('.catalogCount').textContent = cart[productId].count;
        
    }

    function deleteFromCart() {
        renderItems.addEventListener('click', event => {
            if (event.target.tagName == 'IMG') {
				console.log(catalogCount)
				catalogCount.innerHTML=cart[productId].count--;
				
				
             
            }
        });
    } 
            
    deleteFromCart();
	
	
});
*/
